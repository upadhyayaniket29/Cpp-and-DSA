
#include <iostream>

using namespace std;

int main()
{
//   int i;
//   for(i=101;i<=200;i++)
//   cout<<i<<endl;
//   char name;
//   for(name='a';name<='z';name=name+1){
//   cout<<name<<endl;

// int n,i;

// cin>>n;
//  for(i=n;i>=1;i--){
//  cout<<i<<endl;

// int i;
// for(i=1;i<=100;i=i+3)
// {
//     cout<<i<<endl;

// int i,n;
// n=10;
// for(int i=1;i<n;i++)
// {
//     cout<<i<<" ";
// }

int i,n;
cout<<"enter the table ";
cin>>n;
for(i=1;i<=10;i++){
    cout<<n<<"*"<<i<<"="<<n*i<<endl;
}

 
 
   

   
        return 0;
    
}