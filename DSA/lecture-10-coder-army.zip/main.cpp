#include<iostream>
using namespace std;
int main(){
    
    // int a=10;
    // int b;
    // // cout<<a++;
    // // cout<<endl<<a;
    // cout<<--a<<endl;
    // cout<<++a<<endl;
    // b=5>4>3;
    // cout<<b;
    
    // Comparision operator
    // 1 or 0 
    // int a,b;
    // cout<<"enter the value of a";
    // cin>>a;
    // cout<<"enter the value of b";
    // cin>>b;
    
    // == 
    // if (a==b)
    // {
    //     cout<<"yes";
    // }
    // else
    // cout<<"no";
    
    //  > Greater operator
    // >= Greaterthan equal to 
    // if (a>=b)
    // {
    //     cout<<"yes";
    // }
    // else
    // cout<<"no";
    // != Not equal to
    // if(a != b)
    // cout<<"yes";
    // else
    // cout<<"no";
    
    // Logical Operator 
    
    // int a,b,c;
    // cin>>a>>b>>c;
    
    // if(a>b && a>c)
    // cout<<"yes";
    // else
    // cout<<"no";
    // char name;
    // cout<<"enter name";
    // cin>>name;
    // if(name=='a'||name=='e'||name=='i'||name=='o'||name=='u')
    // cout<<"vowel";
    // else
    // cout<<"consonant";
    
    // Not Opeartor
    
    // cout<<!23;
    // cout<<!0;
    
    // Bitwise Opeartor
    // & and Opeartor
    
    // int ans =2&3;
    // cout<<ans;
    // | Or Opeartor 
    // int ans=2|3;
    // cout<<ans;
    // EX-OR Opeartor ^
    // int ans=2^3;
    // cout<<ans;
    // Left shift opeartor <<
    // int ans=0<<0;
    // cout<<ans;
    // Right Shift opeartor
    // int ans=100>>6;
    // int ans=18>>3;
    // cout<<ans;
    // Compliment
//   /Assignment opeartor 
   int a=10;
   a+=5;
   cout<<a;
   
   if(5>4>3)
   cout<<"yes";
   else
   cout<<"no";
    
    
    
    
}

