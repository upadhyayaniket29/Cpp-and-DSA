#include <iostream>

using namespace std;
int c=45;

int main()
{
   // int a,b,c;
   int d,e;
    float=34.4;
    long double e=34.8;
    cout<<"the value of d is :"<<d;
    cout<<"the value of e is:"<<e;
    
    
    //cout<<"Enter the values of a:";
    //cin>>a;
    //cout<<"enter the values of b:";
    //cin>>b;
    //c=a+b;
    //cout<<"the sum is :"<<c<<endl;
    //cout<<"the global c is:"<<::c;

    return 0;
}