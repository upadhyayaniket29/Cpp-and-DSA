#include<iostream>
using namespace std;
int main(){
//     int i=1;
//     int sum;
//     sum=0;
//     int n;
//     cout<<"enter the value of n";
//     cin>>n;
    
//     do{
        
        
        
//          i++;
//         sum=sum+i;
//         cout<<sum;
        
       
//     }
//     while(i<=n);
    
    
// }
//  Continue 
for(int i=1;i<100;i++){
    
    if(i%4==0)
        
    
    continue;
    
    
cout<<i<<" ";

}

}



