/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
// {  int i,n;
//       cin>>n;
//     for(int i=n;i<=10*n;i=i+n)
//     cout<<i<<endl;
{
// int n,pow,num;
// cout<<"enter the number";
// cin>>n;
// num=n;
// cout<<"enter the power";
// cin>>pow;


// for(int i=1;i<pow;i++)
// {
//     num=num*n;
// }

// cout<<num;

// int i,n,sum;

// cout<<"enetr the number";
// cin>>n;
// sum=0;
// for(i=1;i<=n;i++){
//     sum=sum+i;
    
// }

// cout<<sum;

// int i,n;
// cout<<"enter the number ";
// cin>>n;



// cout<<n*(n+1)/2;

// int i,n,sum;
// cout<<"enter the number";
// cin>>n;

// sum=0;

// for(i=1;i<=n;i++)
// {
//     sum=sum+i*i;
    
// }
// cout<<sum;

int i,n,fact;
cout<<"enetr the number";
cin>>n;

fact=1;
for(i=1;i<=n;i++)
{
    fact=fact*i;
   
}
cout<<fact;



 
}