#include<iostream>
using namespace std;
int main(){
    int marks;
    cout<<"enter the marks";
    cin>>marks;
    if(marks>60)
    {cout<<"pass with 1 st divison" ;
    }
    if(marks>55&&marks<60)
    {cout <<"pass with 2nd division";
    }
    if (marks>33&&marks<55)
    {cout<<"third";
    }
        if(marks<33)
        {cout<<"fail";
        }
        return 0;
    
}