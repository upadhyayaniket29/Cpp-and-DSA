/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{ int row,col;
    // for(row=1;row<=5;row=row+1){
    //     for(col=1;col<=6;col=col+1){
            
    //         cout<<"4"<<"";
            
    //     }
    //     cout<<endl;
        
        
    // }
    
    // for(row=1;row<=6;row=row+1){
    //     for(col=1;col<=5;col++){
            
    //         cout<<col*col<<" ";
            
    //     }cout<<endl;
    // }
    
    // for(row=1;row<=5;row++){
    //     for(col=1;col<=6;col++){
    //         cout<<col*col*col<<" ";
    //     }
    //     cout<<endl;
    // }
    
    char name='f';
    
    for(row=1;row<=5;row++)
{ 
    for(col=1;col<=6;col++){
        
       char name='f'+ col-1;
        cout<<name;
    }
    cout<<endl;
}    
    
    
    
    
}


