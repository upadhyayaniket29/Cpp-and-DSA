#include<iostream>
using namespace std;
int main(){
    int i;
    for(i=5,i>=1;i++;)
    {cout<<i;
}
return 0;
}