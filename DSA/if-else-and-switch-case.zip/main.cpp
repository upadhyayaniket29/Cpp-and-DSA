#include<iostream>
using namespace std;

int main(){
    int age;
    cout<<"tell me your age"<<endl;
    cin>>age;
    //if((age<18) &&(age>1)){
      //  cout<<"you can't come to my party"<<endl;
    //}
    
    //else if (age==18){
      //  cout<<"you are a kid and you will get a kid pass to party"<<endl;
        
        
    //}
    //else if(age<1){
      //  cout<<"you are not yet born";
    //}
    //else {
      //  cout<<"you can come to party"<<endl;
    //}
    switch(age)
    {case 18:
    cout<<"you are 18"<<endl;
    //break;
    {case 2:
    cout<<"you are 2"<<endl;
    break;
    
    default:
    cout<<"no special cases"<<endl;
    break;}
    }
    cout<<"my name is switch case";
    
    
    return 0;
}