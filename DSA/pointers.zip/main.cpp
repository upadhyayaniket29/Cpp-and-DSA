
#include <iostream>
using namespace std;
int main(){
    int a=3;
    int* b;
    b= &a;
    cout<<"the address of a is "<<&a<<endl;
    cout<<"the address of b is "<<b<<endl;
    cout<<"the value at address b is"<<*b<<endl;
    
    //Pointer to Pointer
    int**c= &b;
    cout<<"the address of b is "<<*b<<endl;
    cout<<"the address of c is "<<c<<endl;
    cout<<"the value at address c is"<<*c<<endl;
    cout<<"the value at address value at (value at c)"<<**c<<endl;
    return 0;
    
}