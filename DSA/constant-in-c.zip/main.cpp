
#include<iostream>
using namespace std;

int main(){
   // int a=45;
    //cout<<"the value of a is:"<<a<<endl;
    //a=34;
    //cout<<"the value of a is : "<<a<<endl;
    //*****Constants in c++*******
    const long double a=3.1111111;
    cout<<"the value of a was :"<<a;
  // a=45;
    //cout<<"the value of a is :"<<a;
    
    
    
    return 0;
}