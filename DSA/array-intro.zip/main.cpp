#include<iostream>
using namespace std;
int main(){
    int  marks[5]={12,13,14,15,16} ;
    int mathmarks[4];
     mathmarks[0]=23;
     mathmarks[1]=24;
     mathmarks[2]=25;
     mathmarks[3]=26;
     
     
     cout<<"these are marks:"<<endl;
     marks[2]=3444;
     cout<<marks[0]<<endl;
     cout<<marks[1]<<endl;
     cout<<marks[2]<<endl;
     cout<<marks[3]<<endl;
     cout<<marks[4]<<endl;
     cout<<"these are math marks:"<<endl;
     mathmarks[3]=2333;
     cout<<mathmarks[0]<<endl;
     cout<<mathmarks[1]<<endl;
     cout<<mathmarks[2]<<endl;
     cout<<mathmarks[3]<<endl;
     int i;
     for(i=1;i<=4;i++)
     cout<<"the value of marks is : "<<i<<" is "<<marks[i]<<endl;
     
     return 0;
}