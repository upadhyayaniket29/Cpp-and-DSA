#include<iostream>
using namespace std;
int main(){
    int n;
    cout<<"enter the value of n";
    cin>>n;
    
    
    int i=1;
     while(i<=10){
     
     cout<<i*n<<endl;
     i++;
     }
}
