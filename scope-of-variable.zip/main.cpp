
#include <iostream>

using namespace std;

int main()
{
    
    // int n=10;
    // int i=30;
    // {
    //   char n='a';
    //   cout<<n<<endl;
    // }
    // cout<<n; 
    int i=50;
    for(;i<=100;i++)
    {
        cout<<i<<endl;
    }
    cout<<i;
    return 0;
}